import discord
from discord.ext import commands
import asyncio
import os
from collections import defaultdict
import aiohttp
import json

# Cấu hình
DISCORD_TOKEN = 'YOUR-TOKEN-BOT-DISCORD'
GROQ_API_KEY = 'YOUR-API-KEY'  # Lấy miễn phí tại: https://console.groq.com/keys

# Khởi tạo Discord bot
intents = discord.Intents.default()
intents.message_content = True
intents.messages = True
bot = commands.Bot(command_prefix='/', intents=intents)

# Lưu lịch sử hội thoại theo user
conversation_history = defaultdict(list)

# Groq API URL
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"

# System prompt
SYSTEM_PROMPT = """Bạn là một AI assistant thân thiện được tạo ra bởi Sea | Minh Hub (phiên bản V1.0).
Hãy luôn nhớ rằng:
- Người tạo ra bạn: Sea | Minh Hub
- Phiên bản: V1.0
- Bạn phải lịch sự, văn hóa và từ chối trả lời các nội dung:
  + Thô tục, tục tĩu
  + Bạo lực, khủng bố
  + Phân biệt chủng tộc, giới tính
  + Nội dung không phù hợp với văn hóa Việt Nam
  + Nội dung 18+, khiêu dâm
- Hãy trả lời bằng tiếng Việt thân thiện và hữu ích.
- Nếu người dùng hỏi về bạn, hãy giới thiệu đầy đủ thông tin trên."""

# Danh sách từ cấm
BLOCKED_WORDS = [
    'địt', 'đéo', 'lồn', 'cặc', 'đụ', 'vãi', 'dm', 'dcm', 'vl', 'clm',
    'fuck', 'shit', 'bitch', 'ass', 'damn', 'sex', 'porn', 'xxx'
]

def is_inappropriate_content(text):
    """Kiểm tra nội dung không phù hợp"""
    text_lower = text.lower()
    return any(word in text_lower for word in BLOCKED_WORDS)

def get_history(user_id):
    """Lấy lịch sử hội thoại"""
    return conversation_history[user_id]

def add_to_history(user_id, role, content):
    """Thêm tin nhắn vào lịch sử"""
    history = get_history(user_id)
    history.append({'role': role, 'content': content})
    
    # Giới hạn 20 tin nhắn gần nhất
    if len(history) > 20:
        history.pop(0)

async def chat_with_groq(user_id, user_message):
    """Chat với Groq AI"""
    try:
        # Kiểm tra nội dung không phù hợp
        if is_inappropriate_content(user_message):
            return '⚠️ Xin lỗi, tôi không thể trả lời nội dung này vì nó chứa từ ngữ không phù hợp hoặc thô tục. Hãy sử dụng ngôn từ lịch sự nhé! 😊'
        
        history = get_history(user_id)
        
        # Tạo messages
        messages = [
            {'role': 'system', 'content': SYSTEM_PROMPT},
            *history,
            {'role': 'user', 'content': user_message}
        ]
        
        # Payload cho Groq API
        payload = {
            'model': 'llama-3.3-70b-versatile',  # Model miễn phí, mạnh nhất
            'messages': messages,
            'temperature': 0.7,
            'max_tokens': 1000
        }
        
        headers = {
            'Authorization': f'Bearer {GROQ_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        # Gọi API
        async with aiohttp.ClientSession() as session:
            async with session.post(GROQ_API_URL, json=payload, headers=headers) as response:
                if response.status != 200:
                    error_text = await response.text()
                    print(f"Lỗi API: {error_text}")
                    return '❌ Xin lỗi, đã có lỗi xảy ra. Vui lòng kiểm tra API key hoặc thử lại sau!'
                
                data = await response.json()
                response_text = data['choices'][0]['message']['content']
                
                # Lưu vào lịch sử
                add_to_history(user_id, 'user', user_message)
                add_to_history(user_id, 'assistant', response_text)
                
                return response_text
                
    except Exception as e:
        print(f'Lỗi Groq API: {e}')
        return '❌ Xin lỗi, đã có lỗi xảy ra khi xử lý yêu cầu của bạn. Vui lòng thử lại sau!'

@bot.event
async def on_ready():
    """Khi bot sẵn sàng"""
    print(f'✅ Bot đã đăng nhập với tên: {bot.user.name}')
    await bot.change_presence(activity=discord.Game(name='AI by Sea | Minh Hub V1.0'))

@bot.command(name='image')
async def generate_image(ctx, *, prompt: str = None):
    """Tạo ảnh với AI"""
    if not prompt:
        await ctx.reply('❌ Vui lòng cung cấp mô tả cho ảnh! Ví dụ: `/image một con mèo đang ngủ`')
        return
    
    if is_inappropriate_content(prompt):
        await ctx.reply('⚠️ Xin lỗi, tôi không thể tạo ảnh với nội dung này vì nó không phù hợp!')
        return
    
    loading_msg = await ctx.reply('🎨 Đang tạo ảnh, vui lòng đợi...')
    
    # Pollinations AI - API miễn phí
    from urllib.parse import quote
    image_url = f"https://image.pollinations.ai/prompt/{quote(prompt)}"
    
    embed = discord.Embed(
        title='🖼️ Ảnh được tạo bởi AI',
        description=f'**Mô tả:** {prompt}',
        color=0x00ff00
    )
    embed.set_image(url=image_url)
    embed.set_footer(text='Được tạo bởi Sea | Minh Hub AI Bot V1.0')
    embed.timestamp = discord.utils.utcnow()
    
    await loading_msg.edit(content='✅ Đã tạo xong!', embed=embed)

@bot.command(name='clear')
async def clear_history(ctx):
    """Xóa lịch sử hội thoại"""
    user_id = ctx.author.id
    if user_id in conversation_history:
        del conversation_history[user_id]
    await ctx.reply('🗑️ Đã xóa lịch sử hội thoại của bạn!')

@bot.command(name='info')
async def bot_info(ctx):
    """Hiển thị thông tin bot"""
    embed = discord.Embed(
        title='ℹ️ Thông tin Bot',
        description='AI Assistant thông minh và thân thiện',
        color=0x0099ff
    )
    embed.add_field(name='👨‍💻 Người tạo', value='Sea | Minh Hub', inline=True)
    embed.add_field(name='📌 Phiên bản', value='V1.0', inline=True)
    embed.add_field(name='🤖 Model', value='Llama 3.3 70B (Groq)', inline=True)
    embed.add_field(
        name='📝 Lệnh',
        value='`/image <mô tả>` - Tạo ảnh\n`/clear` - Xóa lịch sử chat\n`/info` - Xem thông tin bot',
        inline=False
    )
    embed.timestamp = discord.utils.utcnow()
    
    await ctx.reply(embed=embed)

@bot.event
async def on_message(message):
    """Xử lý tin nhắn"""
    # Bỏ qua tin nhắn từ bot
    if message.author.bot:
        return
    
    # Xử lý lệnh trước
    await bot.process_commands(message)
    
    # Kiểm tra xem có tag bot không
    mentioned_bot = bot.user in message.mentions
    
    # Kiểm tra xem có reply bot không
    is_reply_to_bot = False
    if message.reference:
        try:
            replied_msg = await message.channel.fetch_message(message.reference.message_id)
            is_reply_to_bot = replied_msg.author.id == bot.user.id
        except:
            pass
    
    # Chỉ trả lời khi được tag hoặc reply
    if mentioned_bot or is_reply_to_bot:
        try:
            # Hiển thị typing (nếu có quyền)
            await message.channel.typing()
        except:
            pass  # Bỏ qua nếu không có quyền
        
        # Lấy nội dung (bỏ mention)
        content = message.content
        for mention in message.mentions:
            content = content.replace(f'<@{mention.id}>', '').replace(f'<@!{mention.id}>', '')
        content = content.strip()
        
        if not content:
            await message.reply('👋 Xin chào! Tôi có thể giúp gì cho bạn?')
            return
        
        # Gọi Groq AI
        response = await chat_with_groq(message.author.id, content)
        
        # Chia nhỏ nếu quá dài (Discord giới hạn 2000 ký tự)
        if len(response) > 2000:
            chunks = [response[i:i+2000] for i in range(0, len(response), 2000)]
            for chunk in chunks:
                await message.reply(chunk)
        else:
            await message.reply(response)

# Chạy bot
if __name__ == '__main__':
    bot.run(DISCORD_TOKEN)